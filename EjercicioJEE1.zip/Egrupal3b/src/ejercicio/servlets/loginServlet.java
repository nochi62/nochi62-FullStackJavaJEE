//package cl.indefensoinformatico.servlets;
package ejercicio.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class loginServlet
 */
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    /*
    @Override
	protected void doGet(HttpServletRequest solicitud, HttpServletResponse respuesta) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String usuario = solicitud.getParameter("usuario");
		String contrasena = solicitud.getParameter("contrasena");
		if ("indefensoInformatico".equals(usuario) && "0023Do".equals(contrasena)) {
			response(respuesta, "logueo pulento!");
		} else {
			response(respuesta, "logueo penca!");
		}
	}
    */
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
	protected void doPost(HttpServletRequest solicitud, HttpServletResponse respuesta) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String usuario = solicitud.getParameter("usuario");
		String contrasena = solicitud.getParameter("contrasena");
		if ("indefenso".equals(usuario) && "0023Do".equals(contrasena)) {
			response(respuesta, "logueo pulento!");
		} else {
			response(respuesta, "logueo penca!");
		}
	}
    
	private void response(HttpServletResponse response, String mensaje) throws IOException {
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head>");
		out.println("<link rel='stylesheet' href='hoja3.css'>"); 
		out.println("</head>");
		out.println("<body>");
		out.println("<h1>Respuesta</h1>");
		out.println("<div class='caja3'>");		
		out.println("<h3>....." + mensaje + "</h3>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
	}

}
