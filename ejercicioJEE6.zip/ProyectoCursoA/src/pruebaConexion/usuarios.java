package pruebaConexion;

public class usuarios {
	private String id_usu;
	private String user;
	private String passw;
	private String nomb;
	private String ru;
	
	public usuarios(String id_usu, String user, String passw, String nomb, String ru) {
		this.id_usu = id_usu;
		this.user = user;
		this.passw = passw;
		this.nomb = nomb;
		this.ru = ru;
	}

	public usuarios(String user, String passw, String nomb, String ru) {
		this.user = user;
		this.passw = passw;
		this.nomb = nomb;
		this.ru = ru;
	}

	public String getId_usu() {
		return id_usu;
	}

	public void setId_usu(String id_usu) {
		this.id_usu = id_usu;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassw() {
		return passw;
	}

	public void setPassw(String passw) {
		this.passw = passw;
	}

	public String getNomb() {
		return nomb;
	}

	public void setNomb(String nomb) {
		this.nomb = nomb;
	}

	public String getRu() {
		return ru;
	}

	public void setRu(String ru) {
		this.ru = ru;
	}

	@Override
	public String toString() {
		return "usuarios [id_usu=" + id_usu + ", user=" + user + ", passw="
				+ passw + ", nomb="
				+ nomb + ", ru="
				+ ru + "]";
	}

	
}
