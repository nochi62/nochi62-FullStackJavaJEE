package pruebaConexion;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

public class ModeloUsuarios {
	private DataSource origenDatos;

	public ModeloUsuarios(DataSource origenDatos) {
		this.origenDatos = origenDatos;

	}

	public List<usuarios> getUsuarios() throws Exception {
		List<usuarios> listusuarios = new ArrayList<>();

		Connection miConexion = null;
		Statement miStatement = null;
		ResultSet miResultSet = null;

		// establecer conexi�n
		miConexion = origenDatos.getConnection();

		// crear sentencia sql
		String instruccionSql = "SELECT * FROM GESTION.USUARIOS";
		miStatement = miConexion.createStatement();

		// ejecutar sql
		miResultSet = miStatement.executeQuery(instruccionSql);

		// recorrer resultset obtenido

		while (miResultSet.next()) {
			String id_usu = miResultSet.getString("ID");
			String user = miResultSet.getString("USERNAME");
			String passw = miResultSet.getString("PASSWORD");
			String nomb = miResultSet.getString("NOMBRE");
			String ru = miResultSet.getString("RUT");

			usuarios temUsu=new usuarios(id_usu, user, passw, nomb, ru);
			listusuarios.add(temUsu);
		}
		
		return listusuarios;

	}
}
