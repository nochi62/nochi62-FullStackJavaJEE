package pruebaConexion;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class ControladorUsuarios
 */
public class ControladorUsuarios extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ModeloUsuarios modUsuarios;

	@Resource(name = "jdbc/Usuarios")
	private DataSource miPool;

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();

		try {
			modUsuarios = new ModeloUsuarios(miPool);
		} catch (Exception e) {
			throw new ServletException(e);
		}

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		// obtener lista de usuarios esde el modelo

		List<usuarios> lisusuarios;

		try {
			lisusuarios = modUsuarios.getUsuarios();

			// agregar lista de usuarios al request
			request.setAttribute("LISTAUSUARIOS", lisusuarios);

			// enviar ese request a p�g jsp
			RequestDispatcher miDispatcher = request
					.getRequestDispatcher("/Listausuarios.jsp");
			miDispatcher.forward(request, response);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
